#statistique univarie

#package necessaire

library(gtsummary)
library(ggplot2)
library(flextable)


univarie <- function(variable, base) {
  tableau <- base %>%
    select({{ variable }}) %>%
    tbl_summary() %>%
    bold_labels() %>%
    modify_header(label = "**Variable**") %>%
    modify_footnote(all_stat_cols() ~ "Sortie") %>%
    modify_caption("Statistiques descriptives Univariées") %>%
    bold_labels() %>%
    italicize_levels() %>%
    modify_header(update = list(label = "**Variable**")) %>%
    as_flex_table()
  
  # création du graphique selon le type de données
  if (is.numeric(base[[variable]])) {
    colors_qualitative <- c("A" = "blue", "B" = "green", "C" = "red")  # couleurs pour le graphique
    
    graphique <- ggplot(base, aes(x = .data[[variable]], fill = as.factor(.data[[variable]]))) +
      geom_histogram(binwidth = 1, color = "black", alpha = 0.7) +
      scale_fill_manual(values = colors_qualitative) +
      labs(title = paste("Histogramme de", variable), x = variable, y = "Fréquence")
    
    print(graphique)
    
  } else {  # diagramme à secteurs pour les variables qualitatives
    graphique  <- ggplot(base, aes(x = .data[[variable]])) +
      geom_bar(fill = "blue", color = "black") +
      labs(title = paste("Diagramme en barres de", variable), x = variable, y = "Fréquence")
    print(graphique)
  }
  
  return(tableau)
}