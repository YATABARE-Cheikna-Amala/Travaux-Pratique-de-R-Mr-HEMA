#importation de la base de données à partir du package read_excel
# affectation de la base de données en projet

library(readxl)
Base_Projet <- read_excel("donnees/Base_Projet.xlsx")
View(Base_Projet)
projet <- Base_Projet


# determination du nombre de lignes
nombre_ligne <- nrow(projet)
print(nombre_ligne)


# determination du nombre de colonnes
nombre_colonne <- ncol(projet)
print(nombre_colonne)


#verification des valeurs manquantes de la variable key
valeur_manquante <- sum(is.na(projet$key))
print(valeur_manquante)


