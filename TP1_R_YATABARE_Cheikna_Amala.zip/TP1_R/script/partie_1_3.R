#importation du package dplyr
library(dplyr)


#creation de variable
#renommer la variable q1 en region
projet <- projet %>% dplyr::rename("region" = "q1")
head(projet)


#renommer la variable q2 en departement
projet <- projet %>% dplyr::rename("departement" = "q2")


#renommer la variable q23 en sexe
projet <- projet %>% dplyr::rename("sexe" = "q23")


#creation de la variable sexe_2 prenant les valeurs 0 pour Homme et 1 pour femme
projet <- projet  %>% mutate(sexe_2 = recode_factor(sexe , "Homme"=0 , "Femme" = 1))


#creation de la variable parle qui compte le nombre de langue 
projet <- projet  %>% dplyr::mutate(parle = q24a_1+q24a_2+q24a_3+q24a_4+
                                      q24a_5+q24a_6+q24a_7+
                                      q24a_9+q24a_10)


#creation d'un dataframe langues
langues <- projet  %>% dplyr::select(c("key" , "parle" ))


#mergeons les dataframe projet et langue a partir de la clé KEY
merge_data<- merge(projet, langues , by = "key") 


#visualisation des bases de donnée finale
View(projet)
View(langues)
View(merge_data)
