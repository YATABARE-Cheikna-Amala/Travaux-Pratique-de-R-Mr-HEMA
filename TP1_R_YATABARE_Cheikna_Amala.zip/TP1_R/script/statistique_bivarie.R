#Statistiques descriptives Bivariées

#package necessaire

library(gtsummary)
library(ggplot2)
library(flextable)


bivarie <- function(variable1, variable2, base) {
  tableau <- base %>%
    select({{ variable1 }}, {{ variable2 }}) %>%
    tbl_summary(by = {{ variable2 }}) %>%
    bold_labels() %>%
    modify_header(label = "**Variable**") %>%
    modify_footnote(all_stat_cols() ~ "Sortie") %>%
    modify_caption("Statistiques descriptives Bivariées") %>%
    bold_labels() %>%
    italicize_levels() %>%
    modify_header(update = list(label = "**Variable**")) %>%
    as_flex_table()
  
  if (is.numeric(base[[variable1]]) && is.numeric(base[[variable2]])) {
    graphique <- ggplot(base, aes(x = .data[[variable1]], y = .data[[variable2]])) +
      geom_point(color = "blue") +
      labs(title = paste("Nuage de points entre", variable1, "et", variable2), x = variable1, y = variable2)
    
    print(graphique)
  } else {
    print("Les deux variables doivent être numériques pour créer un nuage de points.")
  }
  
  return(tableau)
}
